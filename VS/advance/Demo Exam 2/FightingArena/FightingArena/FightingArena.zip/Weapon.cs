﻿namespace FightingArena
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Weapon
    {
        private int size;
        private int solidity;
        private int sharpness;

        public Weapon(int size, int solidity, int sharpness)
        {
            Size = size;
            Solidity = solidity;
            Sharpness = sharpness;
        }

        public int Size { get; set; }
        public int Solidity { get; set; }
        public int Sharpness { get; set; }
    }
}
