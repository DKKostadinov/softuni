﻿namespace DefiningClasses
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Family family = new Family();
            for (int i = 0; i < n; i++)
            {
                List<string> input = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToList();
                Person member = new Person(input[0], int.Parse(input[1]));
                family.AddMember(member);
            }

            List<Person> olderMembers = family.GetListOfOlderMembers();

            foreach (var item in olderMembers)
            {
                Console.WriteLine(item.Name + " - " + item.Age);
            }
        }
    }
}
