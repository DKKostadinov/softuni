﻿
namespace DefiningClasses
{
    using System;
    using System.Collections.Generic;
    public class Car
    {
        public Car(string model, int engineSpeed, int enginePower, int cargoWeight, string cargoType, double tire1Pressure, 
            int tire1Age, double tire2Pressure, int tire2Age, double tire3Pressure, int tire3Age, double tire4Pressure,
            int tire4Age)
        {
            Model = model;
            Engine = new Engine(engineSpeed, enginePower);
            Cargo = new Cargo(cargoWeight, cargoType);
            TireList = new List<Tire>(){
                new Tire(tire1Pressure, tire1Age),
                new Tire(tire2Pressure, tire2Age),
                new Tire(tire3Pressure, tire3Age),
                new Tire(tire4Pressure, tire4Age)
            };
        }
        public string Model { get; set; }
        public Engine Engine { get; set; }
        public Cargo Cargo { get; set; }
        public List<Tire> TireList { get; set; }

        public bool BadTire()
        {
            foreach (var tire in TireList)
            {
                if (tire.TirePressure < 1)
                {
                    return true;
                }
            }
            return false;
        }
    }
}