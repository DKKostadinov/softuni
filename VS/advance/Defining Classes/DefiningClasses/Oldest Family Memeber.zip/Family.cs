﻿namespace DefiningClasses
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Family
    {
        private List<Person> members;

        public Family()
        {
            members = new List<Person>();
        }

        public void AddMember(Person member)
        {
            members.Add(member);
        }

        public Person GetOldestMember()
        {
            Person oldestMember = new Person(int.MinValue);
            foreach (var member in members)
            {
                if (member.Age > oldestMember.Age)
                {
                    oldestMember = member;
                }
            }
            return oldestMember;
        }
    }
}
